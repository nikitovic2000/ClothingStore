package pkg;

public class Product {

    String type;
    String name;
    String brand;
    double price;
    String size;
    String color;

    public Product(String type, String name, String brand, double price, String size, String color) {
        this.type = type;
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.size = size;
        this.color = color;
    }


}

