package pkg;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Product shirt1 = new Product("shirt", "Blue Cotton Shirt", "BrandS", 14.99, "M", "blue");
        Product shirt2 = new Product("shirt", "White Cotton Shirt", "BrandS", 15.99, "M", "wihte");
        Product trousers = new Product("trousers", "Black Cotton Trousers", "BrandT", 29.99, "50", "black");
        Product shoes = new Product("shoes", "Black Leather Shoes", "BrandS", 59.99, "43", "black");
        Product jacket = new Product("shirt", "Black Cotton Suit Jacket", "BrandJ", 99.99, "50", "black");

        ArrayList<Product> cart = new ArrayList<>();
        cart.add(shirt1);
        cart.add(shirt2);
        cart.add(trousers);
        cart.add(shoes);
        cart.add(jacket);

        Cashier.print(cart, LocalDateTime.of(2022, 03, 30, 11, 11, 11));


    }
}