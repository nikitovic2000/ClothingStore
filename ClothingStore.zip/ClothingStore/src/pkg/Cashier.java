package pkg;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Cashier {



    public static void print(ArrayList<Product> cart, LocalDateTime date){

        double discount;
        double discountSum = 0;
        double priceSum = 0;

        System.out.println(date);
        System.out.println("\n");
        System.out.println("---Products---");
        System.out.println("\n");

        for (Product p: cart) {

            if(date.getDayOfWeek().name().equals("TUESDAY")){
                if(p.type.equals("shirt") && cart.size() < 3){
                    discount = (p.price + 0.01) /10;
                    discountSum += discount;
                    priceSum += p.price;
                    System.out.println(p.name + " - " + p.brand + "\n" + "$" + p.price + "\n" + "#discount 10% -$" + discount + "\n");


                }else if(p.type.equals("shirt")){
                    discount = (p.price + 0.01)/5;
                    discountSum += discount;
                    priceSum += p.price;
                    System.out.println(p.name + " - " + p.brand + "\n" + "$" + p.price + "\n" + "#discount 20% -$" + discount + "\n");
                }



                if(p.type.equals("shoes")){
                    discount = (p.price + 0.01)/4;
                    discountSum += discount;
                    priceSum += p.price;
                    System.out.println(p.name + " - " + p.brand + "\n" + "$" + p.price + "\n" + "#discount 25% -$" + discount + "\n");
                }




            }else if(cart.size() >= 3){
                discount = (p.price + 0.01)/5;
                discountSum += discount;
                priceSum += p.price;
                System.out.println(p.name + " - " + p.brand + "\n" + "$" + p.price + "\n" + "#discount 20% -$" + discount + "\n");
            }else {
                priceSum += p.price;
                System.out.println(p.name + " - " + p.brand + "\n" + "$" + p.price + "\n" + "#discount 0% -$" + 0 + "\n");
            }
        }

        System.out.println("--------------------------------------------------------------------");
        System.out.println("SUBTOTAL: $" + Math.round(priceSum*100.0)/100.0);
        System.out.println("DISCOUNT: -$" + Math.round(discountSum*100.0)/100.0);
        System.out.println("\n");
        double total = priceSum - discountSum;
        System.out.println("TOTAL: $" + Math.round(total*100.0)/100.0);


    }

}